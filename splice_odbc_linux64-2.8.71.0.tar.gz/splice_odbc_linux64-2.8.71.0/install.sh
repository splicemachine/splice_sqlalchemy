#!/bin/bash

# 64-bit install file

# XXX - RHEL/Debian diffs (lib paths, etc.)

QUIET=0;
IPADDR='127.0.0.1'
ISROOT=0

# multiarch on Debian uses "lib" for arch-specific libs regardless of
LIBDIR="lib"

# RHEL-based OS uses /usr/lib for 32-bit and /usr/lib64 for 64-bit
# figure this out from rpm
test -e /etc/redhat-release && {
	LIBDIR="$(rpm --eval '%{_libdir}' | xargs basename)"
}

if [[ "$(id -u)" == "0" ]]; then
    INSTALLDIR="/usr/local"
    ISROOT=1
else
    INSTALLDIR="$HOME"
fi

function usage() {
    echo "usage: install.sh [-h] [-q] [-i host]"
    echo "  -q      Use quiet mode-- script will read parameters from command line instead of stdin"
    echo "  -i      If -q is specified, default host for Splice Machine DB Server [127.0.0.1]"
    echo "  -h      Show usage and exit"
    exit 0;
}


while getopts ":qhi:" options;
do
    case "${options}" in
        h)
            usage
            exit 0
            ;;
        q)
            QUIET=1
            ;;
        i)
            IPADDR=${OPTARG}
            ;;
        :)
            echo "Parameter -${OPTARG} requires an argument"
            usage
            exit 1
            ;;
        *)
            echo "Parameter -${OPTARG} is not valid"
            usage
            exit 1
            ;;
     esac
done


if [[ ${QUIET} -eq 0 ]]
then
    if [[ -x /usr/bin/clear ]]; then
        /usr/bin/clear
    fi
    echo "Installing Splice Machine 64-Bit ODBC Driver..."
    echo "-----------------------------------------------"
    echo -n "Install to directory [$INSTALLDIR]: "
    read INPUT_INSTALLDIR

    if [[ "$INPUT_INSTALLDIR" != "" ]]
    then
        INSTALL_DIR="${INPUT_INSTALLDIR}"
    fi

    echo -n "Please enter the IP address for the Splice Machine server [127.0.0.1]? "
    read INPUT_IPADDR

    if [[ "$INPUT_IPADDR" != "" ]]
    then
        IPADDR="${INPUT_IPADDR}";
    fi
else
    echo "Installing Splice Machine 64-Bit ODBC Driver..."
fi

FULLPATH=`echo ${INSTALLDIR}/splice | sed 's,//,/,g'`

if [[ ! -d "$FULLPATH" ]]
then
    mkdir -p ${FULLPATH}/${LIBDIR}
    mkdir -p ${FULLPATH}/errormessages/en-US
fi

cat odbc.template | sed "s#_INSTALLDIR_#$FULLPATH/$LIBDIR#;s#_IPADDR_#$IPADDR#" > odbc.ini
cat odbcinst.template | sed "s#_INSTALLDIR_#$FULLPATH/$LIBDIR#" > odbcinst.ini
cat splice.odbcdriver.template | sed "s#_INSTALLDIR_#$FULLPATH#" > splice.odbcdriver.ini

if [[ ${ISROOT} -eq 1 ]]
then
    chmod 666 odbc*.ini
    chmod 666 splice.odbcdriver.ini
fi

# move required files to a common locatLion
cp -av errormessages/en-US/*.xml ${FULLPATH}/errormessages/en-US
cp -av lib64/*.so ${FULLPATH}/${LIBDIR}
cp -av README ${FULLPATH}/README
cp -av VERSION ${FULLPATH}/VERSION

if [[ ${ISROOT} -eq 1 ]]
then
    # move config files into system area
    if [[ -f "/etc/odbc.ini" ]]
    then
        mv /etc/odbc.ini /etc/odbc.ini.1
    fi
    cp -av odbc.ini /etc/odbc.ini

    if [[ -f "/etc/odbcinst.ini" ]]
    then
        mv /etc/odbcinst.ini /etc/odbcinst.ini.1
    fi
    cp -av odbcinst.ini /etc/odbcinst.ini

    if [[ -f "/etc/splice.odbcdriver.ini" ]]
    then
        mv /etc/splice.odbcdriver.ini /etc/splice.odbcdriver.ini.1
    fi
    cp -av splice.odbcdriver.ini /etc/splice.odbcdriver.ini
else
    # move config files into user area
    if [[ -f "$HOME/.odbc.ini" ]]
    then
        mv $HOME/.odbc.ini $HOME/.odbc.ini.1
    fi
    cp -av odbc.ini $HOME/.odbc.ini

    if [[ -f "$HOME/.odbcinst.ini" ]]
    then
        mv $HOME/.odbcinst.ini $HOME/.odbcinst.ini.1
    fi
    cp -av odbcinst.ini $HOME/.odbcinst.ini

    if [[ -f "$HOME/.splice.odbcdriver.ini" ]]
    then
        mv $HOME/.splice.odbcdriver.ini $HOME/.splice.odbcdriver.ini.1
    fi
    cp -av splice.odbcdriver.ini $HOME/.splice.odbcdriver.ini
fi

if [[ ${QUIET} -eq 0 ]]
then
    echo -n "Installation complete... [enter] "
    read foo
    if [[ -x /usr/bin/clear ]]
    then
        /usr/bin/clear
    fi
fi

cat README

